'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import Link from 'next/link';

interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  tableNumber: number;
}

interface Table {
  number: number;
  capacity: number;
  booked: boolean;
}

export default function BookingPage() {
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [guestCount, setGuestCount] = useState(2);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [availableTables, setAvailableTables] = useState<Table[]>([]);
  const [selectedTable, setSelectedTable] = useState<number | null>(null);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [bookingConfirmed, setBookingConfirmed] = useState(false);
  const [confirmationDetails, setConfirmationDetails] = useState<Booking | null>(null);

  // Initialize tables and load bookings
  useEffect(() => {
    const tables: Table[] = [
      { number: 1, capacity: 2, booked: false },
      { number: 2, capacity: 2, booked: false },
      { number: 3, capacity: 4, booked: false },
      { number: 4, capacity: 4, booked: false },
      { number: 5, capacity: 6, booked: false },
      { number: 6, capacity: 6, booked: false },
    ];
    setAvailableTables(tables);

    const savedBookings = localStorage.getItem('restaurant_bookings');
    if (savedBookings) {
      setBookings(JSON.parse(savedBookings));
    }
  }, []);

  // Update available tables based on selected date/time
  useEffect(() => {
    if (selectedDate && selectedTime) {
      const updatedTables = availableTables.map(table => {
        const isBooked = bookings.some(
          booking =>
            booking.date === selectedDate &&
            booking.time === selectedTime &&
            booking.tableNumber === table.number
        );
        return { ...table, booked: isBooked };
      });
      setAvailableTables(updatedTables);
      setSelectedTable(null);
    }
  }, [selectedDate, selectedTime, bookings]);

  const getAvailableTimes = () => {
    const times = [];
    for (let hour = 11; hour < 22; hour++) {
      times.push(`${hour.toString().padStart(2, '0')}:00`);
      times.push(`${hour.toString().padStart(2, '0')}:30`);
    }
    return times;
  };

  const getMinDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  };

  const getMaxDate = () => {
    const maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 30);
    return maxDate.toISOString().split('T')[0];
  };

  const handleSelectTable = (tableNumber: number) => {
    const table = availableTables.find(t => t.number === tableNumber);
    if (table && !table.booked) {
      setSelectedTable(tableNumber);
    }
  };

  const handleConfirmBooking = () => {
    if (!name || !email || !phone) {
      alert('Please fill in all details');
      return;
    }

    const newBooking: Booking = {
      id: Date.now().toString(),
      name,
      email,
      phone,
      date: selectedDate,
      time: selectedTime,
      guests: guestCount,
      tableNumber: selectedTable!,
    };

    const updatedBookings = [...bookings, newBooking];
    localStorage.setItem('restaurant_bookings', JSON.stringify(updatedBookings));
    setBookings(updatedBookings);
    setConfirmationDetails(newBooking);
    setBookingConfirmed(true);
  };

  if (bookingConfirmed && confirmationDetails) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-12">
        <div className="max-w-md mx-auto px-6">
          <Card className="p-8 text-center border-2 border-green-200 bg-green-50">
            <div className="text-6xl mb-6 animate-bounce">✓</div>
            <h1 className="text-3xl font-bold text-green-900 mb-2">Booking Confirmed!</h1>
            <p className="text-green-700 mb-6">Your reservation has been successfully saved</p>
            
            <div className="bg-white p-6 rounded-lg mb-6 text-left space-y-3 border border-green-200">
              <div className="pb-3 border-b border-gray-200">
                <p className="text-xs text-gray-600">GUEST NAME</p>
                <p className="text-lg font-semibold text-gray-900">{confirmationDetails.name}</p>
              </div>
              <div className="pb-3 border-b border-gray-200">
                <p className="text-xs text-gray-600">DATE & TIME</p>
                <p className="text-lg font-semibold text-gray-900">{confirmationDetails.date} at {confirmationDetails.time}</p>
              </div>
              <div className="pb-3 border-b border-gray-200">
                <p className="text-xs text-gray-600">PARTY SIZE</p>
                <p className="text-lg font-semibold text-gray-900">{confirmationDetails.guests} Guests</p>
              </div>
              <div>
                <p className="text-xs text-gray-600">TABLE NUMBER</p>
                <p className="text-lg font-semibold text-gray-900">Table #{confirmationDetails.tableNumber}</p>
              </div>
            </div>
            
            <p className="text-gray-600 mb-6 text-sm">A confirmation email has been sent to <span className="font-semibold">{confirmationDetails.email}</span></p>
            
            <Link href="/">
              <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                Back to Home
              </Button>
            </Link>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 py-12">
      <div className="max-w-2xl mx-auto px-6">
        <Link href="/" className="mb-8 inline-flex items-center text-amber-600 hover:text-amber-700 font-medium">
          ← Back to Home
        </Link>

        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            {[1, 2, 3].map(s => (
              <div key={s} className="flex items-center flex-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition ${
                  s === step 
                    ? 'bg-amber-600 text-white' 
                    : s < step 
                    ? 'bg-green-600 text-white' 
                    : 'bg-gray-300 text-gray-700'
                }`}>
                  {s < step ? '✓' : s}
                </div>
                {s < 3 && <div className={`h-1 flex-1 mx-2 ${s < step ? 'bg-green-600' : 'bg-gray-300'}`}></div>}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-xs text-gray-600">
            <span>Date & Time</span>
            <span>Select Table</span>
            <span>Your Details</span>
          </div>
        </div>

        <h1 className="text-4xl font-bold text-amber-900 mb-8">Reserve a Table</h1>

        {/* Step 1: Date, Time, Guests */}
        {step === 1 && (
          <Card className="p-8 mb-6 shadow-lg border-2 border-amber-100">
            <h2 className="text-2xl font-semibold text-amber-900 mb-8">Select Date, Time & Party Size</h2>
            
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-3">Preferred Date</label>
                <input
                  type="date"
                  min={getMinDate()}
                  max={getMaxDate()}
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none transition"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-3">Preferred Time</label>
                <select
                  value={selectedTime}
                  onChange={(e) => setSelectedTime(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none transition"
                >
                  <option value="">Select a time slot</option>
                  {getAvailableTimes().map(time => (
                    <option key={time} value={time}>{time}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-3">Number of Guests</label>
                <div className="flex items-center gap-4">
                  <button
                    onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
                    className="w-12 h-12 rounded-lg bg-gray-200 hover:bg-gray-300 font-bold text-lg transition"
                  >
                    −
                  </button>
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={guestCount}
                    onChange={(e) => setGuestCount(Math.min(10, Math.max(1, parseInt(e.target.value) || 1)))}
                    className="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg text-center focus:border-amber-600 focus:outline-none transition"
                  />
                  <button
                    onClick={() => setGuestCount(Math.min(10, guestCount + 1))}
                    className="w-12 h-12 rounded-lg bg-gray-200 hover:bg-gray-300 font-bold text-lg transition"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>

            <Button
              onClick={() => setStep(2)}
              disabled={!selectedDate || !selectedTime}
              className="w-full mt-8 bg-amber-600 hover:bg-amber-700 text-white py-3 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Next: Select Table
            </Button>
          </Card>
        )}

        {/* Step 2: Select Table */}
        {step === 2 && (
          <Card className="p-8 mb-6 shadow-lg border-2 border-amber-100">
            <h2 className="text-2xl font-semibold text-amber-900 mb-8">Select Your Table</h2>
            <p className="text-gray-600 mb-8">Date: <span className="font-semibold">{selectedDate}</span> | Time: <span className="font-semibold">{selectedTime}</span> | Guests: <span className="font-semibold">{guestCount}</span></p>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
              {availableTables.map(table => (
                <button
                  key={table.number}
                  onClick={() => handleSelectTable(table.number)}
                  disabled={table.booked}
                  className={`p-6 rounded-lg border-2 transition font-medium ${
                    table.booked
                      ? 'bg-red-50 border-red-300 text-gray-500 cursor-not-allowed'
                      : selectedTable === table.number
                      ? 'bg-green-100 border-green-600 text-green-900 shadow-md'
                      : 'bg-white border-gray-300 hover:border-amber-400 hover:shadow-md text-gray-900'
                  }`}
                >
                  <div className="text-3xl font-bold mb-2">#{table.number}</div>
                  <div className="text-sm">{table.capacity} Seats</div>
                  {table.booked && <div className="text-xs mt-3 text-red-600 font-semibold">Booked</div>}
                  {selectedTable === table.number && <div className="text-xs mt-3 text-green-700 font-semibold">Selected</div>}
                </button>
              ))}
            </div>

            <div className="flex gap-4">
              <Button
                onClick={() => setStep(1)}
                variant="outline"
                className="flex-1 border-2 py-3 font-semibold"
              >
                Back
              </Button>
              <Button
                onClick={() => setStep(3)}
                disabled={selectedTable === null}
                className="flex-1 bg-amber-600 hover:bg-amber-700 text-white py-3 font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next: Your Details
              </Button>
            </div>
          </Card>
        )}

        {/* Step 3: Personal Details */}
        {step === 3 && (
          <Card className="p-8 mb-6 shadow-lg border-2 border-amber-100">
            <h2 className="text-2xl font-semibold text-amber-900 mb-8">Your Contact Details</h2>
            
            <div className="space-y-5 mb-8">
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-2">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none transition"
                  placeholder="John Doe"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none transition"
                  placeholder="john@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none transition"
                  placeholder="+91 "
                />
              </div>
            </div>

            {/* Booking Summary */}
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-lg mb-8 border-2 border-amber-200">
              <h3 className="font-bold text-amber-900 mb-4 text-lg">Booking Summary</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-gray-600 text-xs">Date</p>
                  <p className="font-semibold text-gray-900">{selectedDate}</p>
                </div>
                <div>
                  <p className="text-gray-600 text-xs">Time</p>
                  <p className="font-semibold text-gray-900">{selectedTime}</p>
                </div>
                <div>
                  <p className="text-gray-600 text-xs">Guests</p>
                  <p className="font-semibold text-gray-900">{guestCount} People</p>
                </div>
                <div>
                  <p className="text-gray-600 text-xs">Table</p>
                  <p className="font-semibold text-gray-900">#{selectedTable}</p>
                </div>
              </div>
            </div>

            <div className="flex gap-4">
              <Button
                onClick={() => setStep(2)}
                variant="outline"
                className="flex-1 border-2 py-3 font-semibold"
              >
                Back
              </Button>
              <Button
                onClick={handleConfirmBooking}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-3 font-semibold"
              >
                Confirm Booking
              </Button>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
