import { Button } from "@/components/ui/button";

export default function FeedbackPage() {
    return (
        <main className="min-h-screen flex flex-col items-center justify-center bg-amber-50 p-6">
            <div className="bg-white shadow-md rounded-lg p-8 max-w-md w-full border border-amber-200">
                <h1 className="text-3xl font-bold text-amber-900 mb-4 text-center">
                    Feedback
                </h1>

                <p className="text-gray-700 mb-6 text-center">
                    Tell us about your experience.
                </p>

                <form className="flex flex-col gap-4">
                    <textarea
                        className="w-full border border-amber-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-amber-500"
                        rows={5}
                        placeholder="Write your feedback here..."
                    />

                    <Button className="bg-amber-700 hover:bg-amber-800 text-white w-full">
                        Submit Feedback
                    </Button>
                </form>
            </div>
        </main>
    );
}
