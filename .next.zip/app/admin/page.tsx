'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

interface Booking {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  tableNumber: number;
}

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [password, setPassword] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filterDate, setFilterDate] = useState('');
  const [stats, setStats] = useState({ totalBookings: 0, todayBookings: 0, totalGuests: 0, totalTables: 6 });

  // Load bookings on mount
  useEffect(() => {
    const savedBookings = localStorage.getItem('restaurant_bookings');
    if (savedBookings) {
      const parsedBookings = JSON.parse(savedBookings);
      setBookings(parsedBookings);
      calculateStats(parsedBookings);
    }
  }, []);

  const calculateStats = (allBookings: Booking[]) => {
    const today = new Date().toISOString().split('T')[0];
    const todayBookings = allBookings.filter(b => b.date === today);
    const totalGuests = allBookings.reduce((sum, b) => sum + b.guests, 0);

    setStats({
      totalBookings: allBookings.length,
      todayBookings: todayBookings.length,
      totalGuests,
      totalTables: 6,
    });
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsAuthenticated(true);
      setPassword('');
    } else {
      alert('Invalid password');
    }
  };

  const handleCancelBooking = (id: string) => {
    if (window.confirm('Are you sure you want to cancel this booking?')) {
      const updatedBookings = bookings.filter(b => b.id !== id);
      setBookings(updatedBookings);
      localStorage.setItem('restaurant_bookings', JSON.stringify(updatedBookings));
      calculateStats(updatedBookings);
    }
  };

  const filteredBookings = filterDate
    ? bookings.filter(b => b.date === filterDate)
    : bookings.sort((a, b) => {
        const dateA = new Date(`${a.date}T${a.time}`);
        const dateB = new Date(`${b.date}T${b.time}`);
        return dateA.getTime() - dateB.getTime();
      });

  const getMinDate = () => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center py-12 px-4">
        <div className="bg-white p-10 rounded-lg shadow-lg w-full max-w-sm border-2 border-amber-200">
          <h1 className="text-3xl font-bold text-amber-900 mb-2">Admin Login</h1>
          <p className="text-gray-600 mb-8">Enter your password to access the dashboard</p>

          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-gray-800 mb-2">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none transition"
                placeholder="Enter admin password"
                autoFocus
              />
              <p className="text-xs text-amber-700 mt-3 bg-amber-50 p-3 rounded font-medium">Demo password: <span className="font-mono">admin123</span></p>
            </div>

            <Button type="submit" className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 font-semibold">
              Login to Dashboard
            </Button>
          </form>

          <Link href="/" className="block text-center mt-6 text-amber-600 hover:text-amber-700 font-medium">
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <div className="bg-white shadow-md border-b-4 border-amber-600">
        <div className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-amber-900">Admin Dashboard</h1>
            <p className="text-gray-600 text-sm mt-1">Manage all restaurant reservations</p>
          </div>
          <button
            onClick={() => setIsAuthenticated(false)}
            className="text-red-600 hover:text-red-700 font-semibold hover:bg-red-50 px-4 py-2 rounded-lg transition"
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-blue-600">
            <div className="text-gray-600 text-sm font-semibold mb-2">Total Bookings</div>
            <div className="text-4xl font-bold text-blue-600">{stats.totalBookings}</div>
            <p className="text-xs text-gray-500 mt-2">All time reservations</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-orange-600">
            <div className="text-gray-600 text-sm font-semibold mb-2">Today's Bookings</div>
            <div className="text-4xl font-bold text-orange-600">{stats.todayBookings}</div>
            <p className="text-xs text-gray-500 mt-2">Reservations for today</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-600">
            <div className="text-gray-600 text-sm font-semibold mb-2">Total Guests Booked</div>
            <div className="text-4xl font-bold text-green-600">{stats.totalGuests}</div>
            <p className="text-xs text-gray-500 mt-2">Across all reservations</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-purple-600">
            <div className="text-gray-600 text-sm font-semibold mb-2">Available Tables</div>
            <div className="text-4xl font-bold text-purple-600">{stats.totalTables}</div>
            <p className="text-xs text-gray-500 mt-2">Restaurant capacity</p>
          </div>
        </div>

        {/* Bookings Table */}
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-6 border-b-2 border-gray-200">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <h2 className="text-2xl font-bold text-amber-900">All Bookings</h2>
              <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
                <input
                  type="date"
                  value={filterDate}
                  onChange={(e) => setFilterDate(e.target.value)}
                  min={getMinDate()}
                  className="px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-amber-600 focus:outline-none"
                />
                {filterDate && (
                  <button
                    onClick={() => setFilterDate('')}
                    className="px-4 py-2 text-amber-600 hover:text-amber-700 font-semibold bg-amber-50 rounded-lg hover:bg-amber-100 transition"
                  >
                    Clear Filter
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b-2 border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Name</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Email</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Phone</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Date</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Time</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Guests</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Table</th>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-800">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredBookings.length > 0 ? (
                  filteredBookings.map((booking, index) => (
                    <tr key={booking.id} className={`border-b border-gray-100 hover:bg-gray-50 transition ${
                      index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                    }`}>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{booking.name}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{booking.email}</td>
                      <td className="px-6 py-4 text-sm text-gray-600">{booking.phone}</td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{booking.date}</td>
                      <td className="px-6 py-4 text-sm font-medium text-gray-900">{booking.time}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">
                        <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-semibold">
                          {booking.guests}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm font-bold text-amber-700">#{booking.tableNumber}</td>
                      <td className="px-6 py-4 text-sm">
                        <button
                          onClick={() => handleCancelBooking(booking.id)}
                          className="text-red-600 hover:text-red-800 font-bold hover:bg-red-50 px-3 py-1 rounded transition"
                        >
                          Cancel
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-gray-500 font-medium">
                      No bookings found for the selected date
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
