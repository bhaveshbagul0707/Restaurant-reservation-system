import Link from 'next/link';
import { Button } from '@/components/ui/button';

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50">
      {/* Navigation */}
      <nav className="flex justify-between items-center px-8 py-6 bg-white shadow-sm border-b border-amber-100">
        <h1 className="text-2xl font-bold text-amber-900">The Grill House</h1>
        <div className="flex gap-4">
          <Link href="/booking">
            <Button variant="outline" className="border-amber-300 text-amber-900 hover:bg-amber-50">Book a Table</Button>
          </Link>
          <Link href="/admin">
            <Button variant="ghost" className="text-amber-700 hover:bg-amber-50">Admin</Button>
          </Link>
        </div>
<Link href="/feedback">
  <Button variant="outline" className="border-amber-300 text-amber-900 hover:bg-amber-50">
    Feedback
  </Button>
</Link>

      </nav>

      {/* Hero Section */}
      <div className="max-w-4xl mx-auto px-8 py-24 text-center">
        <h2 className="text-5xl font-bold text-amber-900 mb-6 text-balance">Welcome to The Grill House</h2>
        <p className="text-xl text-gray-700 mb-4 text-pretty">Experience exceptional dining with ease. Reserve your table in seconds.</p>
        <p className="text-lg text-gray-600 mb-12">Open daily from 11:00 AM to 10:00 PM</p>
        
        <Link href="/booking">
          <Button size="lg" className="bg-amber-600 hover:bg-amber-700 text-white px-8 py-6 text-lg">
            Reserve Your Table
          </Button>
        </Link>
      </div>

      {/* Features Section */}
      <div className="max-w-5xl mx-auto px-8 py-16 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-8 rounded-lg shadow-sm border border-amber-100 hover:shadow-md transition">
            <div className="text-4xl mb-4">📅</div>
            <h3 className="text-xl font-semibold text-amber-900 mb-3">Easy Booking</h3>
            <p className="text-gray-600 leading-relaxed">Choose your preferred date and time in just a few clicks</p>
          </div>
          <div className="bg-white p-8 rounded-lg shadow-sm border border-amber-100 hover:shadow-md transition">
            <div className="text-4xl mb-4">🪑</div>
            <h3 className="text-xl font-semibold text-amber-900 mb-3">Select Table</h3>
            <p className="text-gray-600 leading-relaxed">Pick the perfect table that suits your group size</p>
          </div>
          <div className="bg-white p-8 rounded-lg shadow-sm border border-amber-100 hover:shadow-md transition">
            <div className="text-4xl mb-4">✓</div>
            <h3 className="text-xl font-semibold text-amber-900 mb-3">Instant Confirmation</h3>
            <p className="text-gray-600 leading-relaxed">Get immediate confirmation and reservation details</p>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-to-r from-amber-100 to-orange-100 py-16 mt-16">
        <div className="max-w-3xl mx-auto px-8 text-center">
          <h3 className="text-3xl font-bold text-amber-900 mb-4">Ready to dine with us?</h3>
          <p className="text-lg text-gray-700 mb-8">Book your reservation now and enjoy an unforgettable experience</p>
          <Link href="/booking">
            <Button size="lg" className="bg-amber-700 hover:bg-amber-800 text-white px-8 py-3">
              Book Now
            </Button>
          </Link>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-amber-900 text-amber-50 py-8 mt-16">
        <div className="max-w-6xl mx-auto px-8 text-center">
          <p className="text-amber-100">© 2025 The Grill House. All rights reserved.</p>
          <p className="text-amber-200 text-sm mt-2">Crafted with care for your dining experience</p>
        </div>
      </footer>
    </main>
  );
}
