(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b0f6a_next_dist_compiled_8064e16f._.js",
  "static/chunks/b0f6a_next_dist_shared_lib_92af8b32._.js",
  "static/chunks/b0f6a_next_dist_client_8dd4ae3a._.js",
  "static/chunks/b0f6a_next_dist_393df2a2._.js",
  "static/chunks/b0f6a_next_error_5bd8c792.js",
  "static/chunks/[next]_entry_page-loader_ts_1113c721._.js",
  "static/chunks/b0f6a_react-dom_6a724682._.js",
  "static/chunks/b0f6a_b775517b._.js",
  "static/chunks/[root-of-the-server]__b0a87522._.js"
],
    source: "entry"
});
