(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/b0f6a_5bda0953._.js",
  "static/chunks/Desktop_code_160afd03._.js"
],
    source: "dynamic"
});
