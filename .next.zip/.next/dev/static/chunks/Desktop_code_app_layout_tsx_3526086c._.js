(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ddf07ddc._.css",
  "static/chunks/b0f6a_1746c9ec._.js"
],
    source: "dynamic"
});
