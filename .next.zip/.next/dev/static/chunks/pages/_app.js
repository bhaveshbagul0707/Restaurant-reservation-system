__turbopack_load_page_chunks__("/_app", [
  "static/chunks/b0f6a_next_dist_compiled_8064e16f._.js",
  "static/chunks/b0f6a_next_dist_shared_lib_2bdb53ab._.js",
  "static/chunks/b0f6a_next_dist_client_8dd4ae3a._.js",
  "static/chunks/b0f6a_next_dist_af088e73._.js",
  "static/chunks/b0f6a_next_app_87ead3c9.js",
  "static/chunks/[next]_entry_page-loader_ts_183e9ff9._.js",
  "static/chunks/b0f6a_react-dom_6a724682._.js",
  "static/chunks/b0f6a_b775517b._.js",
  "static/chunks/[root-of-the-server]__c4e98b80._.js",
  "static/chunks/Desktop_code_pages__app_2da965e7._.js",
  "static/chunks/turbopack-Desktop_code_pages__app_28817646._.js"
])
