__turbopack_load_page_chunks__("/_error", [
  "static/chunks/b0f6a_next_dist_compiled_8064e16f._.js",
  "static/chunks/b0f6a_next_dist_shared_lib_92af8b32._.js",
  "static/chunks/b0f6a_next_dist_client_8dd4ae3a._.js",
  "static/chunks/b0f6a_next_dist_393df2a2._.js",
  "static/chunks/b0f6a_next_error_5bd8c792.js",
  "static/chunks/[next]_entry_page-loader_ts_1113c721._.js",
  "static/chunks/b0f6a_react-dom_6a724682._.js",
  "static/chunks/b0f6a_b775517b._.js",
  "static/chunks/[root-of-the-server]__b0a87522._.js",
  "static/chunks/Desktop_code_pages__error_2da965e7._.js",
  "static/chunks/turbopack-Desktop_code_pages__error_3f175ed0._.js"
])
