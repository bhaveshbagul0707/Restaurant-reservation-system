module.exports = [
"[project]/Desktop/code/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_code__next-internal_server_app__not-found_page_actions_a8c2a2aa.js.map