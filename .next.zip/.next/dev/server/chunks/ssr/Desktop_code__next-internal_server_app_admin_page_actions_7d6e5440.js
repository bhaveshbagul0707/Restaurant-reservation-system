module.exports = [
"[project]/Desktop/code/.next-internal/server/app/admin/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_code__next-internal_server_app_admin_page_actions_7d6e5440.js.map