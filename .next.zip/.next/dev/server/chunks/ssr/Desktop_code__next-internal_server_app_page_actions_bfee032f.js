module.exports = [
"[project]/Desktop/code/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_code__next-internal_server_app_page_actions_bfee032f.js.map