module.exports = [
"[project]/Desktop/code/.next-internal/server/app/booking/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_code__next-internal_server_app_booking_page_actions_3e25128c.js.map