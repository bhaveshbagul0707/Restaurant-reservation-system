var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_error.js")
R.c("server/chunks/ssr/b0f6a_ec05b157._.js")
R.c("server/chunks/ssr/[externals]_next_dist_shared_lib_no-fallback-error_external_59b92b38.js")
R.c("server/chunks/ssr/b0f6a_8c87e1dd._.js")
R.c("server/chunks/ssr/[root-of-the-server]__e6a4d965._.js")
R.c("server/chunks/ssr/b0f6a_next_bd888862._.js")
R.m("[project]/Desktop/code/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/code/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/code/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/code/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)")
module.exports=R.m("[project]/Desktop/code/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/Desktop/code/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/Desktop/code/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/Desktop/code/node_modules/next/app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)").exports
